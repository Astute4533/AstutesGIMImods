extract zip in mods folder in 3dmigoto, install here if you don't have it already
https://github.com/SilentNightSound/GI-Model-Importer