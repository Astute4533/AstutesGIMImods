EN 
If you have paid for this mod you have been scammed. The only official source is Discord.gg/agmg or the genshin gamebanana page. 
This mod may not be used in social media posts without gaining permission from me (Astute#4533) first. It may also not be resold or redistributed on any other sites. 

CN (可能有错误。使用翻译应用程序)
如果你已经为这个 MOD 付费，那么你就被骗了。唯一的官方来源是 Discord.gg/agmg 或 原神 gamebanana 页面。
未经我 (Astute#4533) 许可，不得在社交媒体帖子中使用此 MOD。它也不得在任何其他网站上转售或重新分发。

JP (翻訳アプリを使用するとエラーが発生する可能性があります)
この MOD の代金を支払った場合は、詐欺に遭ったことになります。唯一の公式ソースは Discord.gg/agmg または genshin gamebanana ページです。
この MOD は、最初に私 (Astute#4533) から許可を得ることなく、ソーシャル メディアの投稿で使用することはできません。また、他のサイトで再販・再配布することもできません。


EN Installation: 
1 - Downlod GIMI at https://github.com/SilentNightSound/GI-Model-Importer and follow setup instructions 
2 - load GIMI 3DM to Genshin 
3 - Place this folder into the Mod folder within GIMI 
4 - Press f10 ingame 

CN 安装：
1 - 在 https://github.com/SilentNightSound/GI-Model-Importer 下载 GIMI 并按照设置说明进行操作
2 - 加载 GIMI 3DM 到 原神
3 - 将此文件夹放入 GIMI 内的 Mod 文件夹中
4 - 在游戏中按 F10

JP インストール:
1 - https://github.com/SilentNightSound/GI-Model-Importer で GIMI をダウンロードし、セットアップ手順に従います。
2 - GIMI 3DM をゲームにロードする
3 - このフォルダーを GIMI 内の Mods フォルダーに置きます
4 - ゲーム内で f10 を押します




THIS IS LISCENED UNDER A Attribution-NonCommercial-NoDerivatives 4.0 International (CC BY-NC-ND 4.0).